<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Add New Customer</h3>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <div class="box-body my-form-body">
          <?php if(isset($msg) || validation_errors() !== ''): ?>
              <div class="alert alert-warning alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-warning"></i> Alert!</h4>
                  <?= validation_errors();?>
                  <?= isset($msg)? $msg: ''; ?>
              </div>
            <?php endif; ?>
           
            <?php echo form_open(base_url('admin/customers/add'), 'class="form-horizontal"');  ?> 
              <div class="form-group">
                <label for="customername" class="col-sm-2 control-label">Customer Name</label>

                <div class="col-sm-9">
                  <input type="text" name="customername" class="form-control" id="customername" placeholder="">
                </div>
              </div>

              <div class="form-group">
                <label for="email" class="col-sm-2 control-label">Email</label>

                <div class="col-sm-9">
                  <input type="email" name="email" class="form-control" id="email" placeholder="">
                </div>
              </div>
              <div class="form-group">
                <label for="mobile_no" class="col-sm-2 control-label">Mobile No</label>

                <div class="col-sm-9">
                  <input type="number" name="mobile_no" class="form-control" id="mobile_no" placeholder="">
                </div>
              </div>
              <div class="form-group">
                <label for="address" class="col-sm-2 control-label">Address</label>

                <div class="col-sm-9">
                  <textarea name="address" class="form-control" id="address" placeholder=""></textarea>
                </div>
              </div>
              <div class="form-group">
                <label for="city" class="col-sm-2 control-label">City</label>

                <div class="col-sm-9">
                  <input type="text" name="city" class="form-control" id="city" placeholder="">
                </div>
              </div>
              <div class="form-group">
                <label for="postalcode" class="col-sm-2 control-label">Postal Code</label>

                <div class="col-sm-9">
                  <input type="text" name="postalcode" class="form-control" id="postalcode" placeholder="">
                </div>
              </div>		
              <div class="form-group">
                <label for="country" class="col-sm-2 control-label">Country</label>

                <div class="col-sm-9">
                  <input type="text" name="country" class="form-control" id="country" placeholder="">
                </div>
              </div>					  
              <div class="form-group">
                <div class="col-md-11">
                  <input type="submit" name="submit" value="Add Customer" class="btn btn-info pull-right">
                </div>
              </div>
            <?php echo form_close( ); ?>
          </div>
          <!-- /.box-body -->
      </div>
    </div>
  </div>  

</section> 


<script>
$("#add_user").addClass('active');
</script>    