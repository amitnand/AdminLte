<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Customers extends MY_Controller {

		public function __construct(){
			parent::__construct();
			$this->load->model('admin/customer_model', 'customer_model');
		}

		public function index(){
			$data['all_users'] =  $this->customer_model->get_all_customers();
			$data['view'] = 'admin/Customers/customer_list';
			$this->load->view('admin/layout', $data);
		}
		
		public function add(){
			if($this->input->post('submit')){

				$this->form_validation->set_rules('customername', 'Customer Name', 'trim|required');
				$this->form_validation->set_rules('email', 'Email', 'trim|required');
				$this->form_validation->set_rules('mobile_no', 'Mobile Number', 'trim|required');
				$this->form_validation->set_rules('address', 'Address', 'trim|required');
				$this->form_validation->set_rules('city', 'City', 'trim|required');
				$this->form_validation->set_rules('postalcode', 'Postal Code', 'trim|required');
				$this->form_validation->set_rules('country', 'Country', 'trim|required');
				
				if ($this->form_validation->run() == FALSE) {
					$data['view'] = 'admin/customers/customer_add';
					$this->load->view('admin/layout', $data);
				}
				else{
					$data = array(
						'customername' => $this->input->post('customername'),
						'email' => $this->input->post('email'),
						'mobile_no' => $this->input->post('mobile_no'),
						'address' =>  $this->input->post('address'),
						'city' => $this->input->post('city'),
						'postalcode' => $this->input->post('postalcode'),
						'country' => $this->input->post('country'),
						'created_at' => date('Y-m-d : h:m:s'),
						'updated_at' => date('Y-m-d : h:m:s'),
					);
					$data = $this->security->xss_clean($data);
					$result = $this->customer_model->add_customer($data);
					if($result){
						$this->session->set_flashdata('msg', 'Record is Added Successfully!');
						redirect(base_url('admin/customers'));
					}
				}
			}
			else{
				$data['view'] = 'admin/customers/customer_add';
				$this->load->view('admin/layout', $data);
			}
			
		}

		public function edit($id = 0){
			if($this->input->post('submit')){
				$this->form_validation->set_rules('customername', 'Customer Name', 'trim|required');
				$this->form_validation->set_rules('email', 'Email', 'trim|required');
				$this->form_validation->set_rules('mobile_no', 'Mobile Number', 'trim|required');
				$this->form_validation->set_rules('address', 'Address', 'trim|required');
				$this->form_validation->set_rules('city', 'City', 'trim|required');
				$this->form_validation->set_rules('postalcode', 'Postal Code', 'trim|required');
				$this->form_validation->set_rules('country', 'Country', 'trim|required');

				if ($this->form_validation->run() == FALSE) {
					$data['customer'] = $this->customer_model->get_customer_by_id($id);
					$data['view'] = 'admin/customers/customer_edit';
					$this->load->view('admin/layout', $data);
				}
				else{
					$data = array(
						'customername' => $this->input->post('customername'),
						'email' => $this->input->post('email'),
						'mobile_no' => $this->input->post('mobile_no'),
						'address' =>  $this->input->post('address'),
						'city' => $this->input->post('city'),
						'postalcode' => $this->input->post('postalcode'),
						'country' => $this->input->post('country'),
						'created_at' => date('Y-m-d : h:m:s'),
						'updated_at' => date('Y-m-d : h:m:s'),
					);
					$data = $this->security->xss_clean($data);
					$result = $this->customer_model->edit_customer($data, $id);
					if($result){
						$this->session->set_flashdata('msg', 'Record is Updated Successfully!');
						redirect(base_url('admin/customers'));
					}
				}
			}
			else{
				$data['customer'] = $this->customer_model->get_customer_by_id($id);
				$data['view'] = 'admin/customers/customer_edit';
				$this->load->view('admin/layout', $data);
			}
		}

		public function del($id = 0){
			$this->db->delete('ci_customers', array('id' => $id));
			$this->session->set_flashdata('msg', 'Record is Deleted Successfully!');
			redirect(base_url('admin/customers'));
		}

	}

?>