<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-14 05:18:35 --> 404 Page Not Found: Dist/img
ERROR - 2022-04-14 05:19:32 --> 404 Page Not Found: Documentation_adminlte/index.html
ERROR - 2022-04-14 05:24:27 --> 404 Page Not Found: admin/Customers/add
ERROR - 2022-04-14 05:24:33 --> 404 Page Not Found: admin/Customers/index
ERROR - 2022-04-14 05:30:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Customer_model C:\xampp\htdocs\ci_lte\system\core\Loader.php 344
ERROR - 2022-04-14 05:31:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Customer_model C:\xampp\htdocs\ci_lte\system\core\Loader.php 344
ERROR - 2022-04-14 05:32:34 --> Severity: error --> Exception: C:\xampp\htdocs\ci_lte\application\models/admin/Customer_model.php exists, but doesn't declare class Customer_model C:\xampp\htdocs\ci_lte\system\core\Loader.php 336
ERROR - 2022-04-14 06:37:36 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 45
ERROR - 2022-04-14 06:37:36 --> Severity: error --> Exception: Call to a member function add_customer() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 45
ERROR - 2022-04-14 06:40:49 --> Severity: error --> Exception: Call to undefined method Customer_model::add_customer() C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 45
ERROR - 2022-04-14 06:42:49 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_list.php 25
ERROR - 2022-04-14 06:42:49 --> Severity: Notice --> Undefined index: lastname C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_list.php 26
ERROR - 2022-04-14 06:42:49 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_list.php 29
ERROR - 2022-04-14 06:42:49 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_list.php 30
ERROR - 2022-04-14 07:33:12 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_list.php 33
ERROR - 2022-04-14 07:33:55 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_list.php 34
ERROR - 2022-04-14 07:34:16 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_list.php 34
ERROR - 2022-04-14 07:36:08 --> Severity: Notice --> Undefined index: is_admin C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_list.php 34
ERROR - 2022-04-14 07:36:35 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 92
ERROR - 2022-04-14 07:36:35 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 92
ERROR - 2022-04-14 07:37:05 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 92
ERROR - 2022-04-14 07:37:05 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 92
ERROR - 2022-04-14 07:39:47 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 92
ERROR - 2022-04-14 07:39:47 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 92
ERROR - 2022-04-14 07:43:45 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 92
ERROR - 2022-04-14 07:43:45 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 92
ERROR - 2022-04-14 07:46:50 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:50 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:52 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:52 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:52 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:52 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:52 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:52 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:53 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:53 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:53 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:53 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:53 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:53 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:53 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:53 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:55 --> Severity: Notice --> Undefined property: Customers::$user_model C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:46:55 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:47:14 --> Severity: error --> Exception: Call to undefined method Customer_model::get_user_by_id() C:\xampp\htdocs\ci_lte\application\controllers\admin\Customers.php 95
ERROR - 2022-04-14 07:47:29 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_edit.php 20
ERROR - 2022-04-14 07:47:29 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_edit.php 25
ERROR - 2022-04-14 07:47:29 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_edit.php 33
ERROR - 2022-04-14 07:47:29 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_edit.php 40
ERROR - 2022-04-14 07:47:29 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_edit.php 48
ERROR - 2022-04-14 07:47:29 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_edit.php 55
ERROR - 2022-04-14 07:47:29 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_edit.php 62
ERROR - 2022-04-14 07:47:29 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\ci_lte\application\views\admin\customers\customer_edit.php 69
ERROR - 2022-04-14 07:58:07 --> 404 Page Not Found: Dist/img
ERROR - 2022-04-14 07:58:20 --> 404 Page Not Found: Widgetshtml/index
ERROR - 2022-04-14 07:58:23 --> 404 Page Not Found: admin/Layout/fixed
ERROR - 2022-04-14 07:58:26 --> 404 Page Not Found: admin/Layout/boxed
